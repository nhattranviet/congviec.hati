<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Congviec extends Model
{
    protected $table = 'tbl_nghenghiep';
}
