<?php
namespace App\Repositories\TaiKhoanRepository;
use Illuminate\Support\Facades\DB;

class TaiKhoanData implements ITaiKhoan {

    public function getAll()
    {
        // TODO: Implement getAll() method.
      return 1;
    }

    function getById($id)
    {
        // TODO: Implement getById() method.
    }

    function create(array $attributes)
    {
        // TODO: Implement create() method.
    }

    function update($id, array $attributes)
    {
        // TODO: Implement update() method.
    }

    function delete($id)
    {
        // TODO: Implement delete() method.
    }
}