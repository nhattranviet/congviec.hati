# Hướng dẫn sử dụng extension
 Thông thường, với những tài khoản bình thường chỉ xem được 3 phút cho mỗi video. Với extension này sẽ giúp bạn xem phim không bị gián đoạn mà không cần phải bỏ tiền nâng cấp VIP
![img](http://i.imgur.com/v83BCYc.jpg)
## Hướng dẫn cài đặt
* Đầu tiên mở trình duyệt lên và vào mục extension
![img](https://i.imgur.com/7gbJlL3.jpg)
* Tick chọn vào chế độ <b>Develop mode</b> sau đó chọn <b>Load unpacked extension...</b>
![img](http://i.imgur.com/2t3csi3.jpg)
* Khi bảng này hiện ra thì chọn forder thư mục mới tải về và giải nén sau đó nhấn ok
![img](https://i.imgur.com/7ac6eiz.jpg)
## Với trình duyệt Cốc Cốc
Ở bước 1 sẽ khác với chrome một tí. Các bước còn lại không có gì thay đổi. 
![img](https://i.imgur.com/VtAliQL.png)
## Với những trình duyệt cùng mã nguồn chrome khác thì vẫn làm tương tự. Mọi thắc mắc giải đáp vui lòng gửi về tại [đây](https://www.facebook.com/Tranducy1999) (ib me)
